package com.rh.financeiro.enterprise;
public class ValidationException extends RuntimeException{
    public ValidationException(String message){
        super(message);
    }
}
