package com.rh.financeiro.enums;

public enum Status {
    TRABALHANDO,
    DEMITIDO,
    AFASTADO
}
