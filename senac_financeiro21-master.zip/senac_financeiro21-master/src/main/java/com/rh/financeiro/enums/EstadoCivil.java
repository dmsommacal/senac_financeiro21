package com.rh.financeiro.enums;

public enum EstadoCivil {
    CASADO,
    SOLTEIRO,
    DIVORCIADO,
    VIUVO
}
