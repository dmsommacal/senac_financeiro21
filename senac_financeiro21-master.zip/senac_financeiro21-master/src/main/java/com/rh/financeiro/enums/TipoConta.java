package com.rh.financeiro.enums;

public enum TipoConta {
    CORRENTE,
    SALARIO,
    POUPANCA
}
