package com.rh.financeiro.enums;

public enum Genero {
    MASCULINO,
    FEMININO,
    OUTROS
}
