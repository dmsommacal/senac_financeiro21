package com.rh.financeiro.enums;

public enum TipoRH {
    A_POSITIVO,
    A_NEGATIVO,
    B_NEGATTIVO,
    B_POSITIVO,
    O_POSITIVO,
    O_NEGATIVO,
    AB_POSITIVO,
    AB_NEGATIVO
}
