package com.rh.financeiro.enums;

public enum ModalidadeContratual {
    CLT,
    PJ
}
