package com.rh.financeiro.enums;

public enum Turno {
    MATUTINO,
    VESPERTINO,
    NOTURNO
}
